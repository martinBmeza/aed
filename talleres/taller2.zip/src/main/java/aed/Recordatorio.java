package aed;

public class Recordatorio {

    public Recordatorio(String mensaje, Fecha fecha, Horario horario) {
        // Implementar
    }

    public Horario horario() {
        // Implementar
        return null;
    }

    public Fecha fecha() {
        // Implementar
        return null;
    }

    public String mensaje() {
        // Implementar
        return "";
    }

    @Override
    public String toString() {
        // Implementar
        return "";
    }

    @Override
    public boolean equals(Object otro) {
        // Implementar
        return true;
    }

}
