package aed;

public class Horario {

    public Horario(int hora, int minutos) {
        // Implementar
    }

    public int hora() {
        // Implementar
        return -1;
    }

    public int minutos() {
        // Implementar
        return -1;
    }

    @Override
    public String toString() {
        // Implementar
        return "";
    }

    @Override
    public boolean equals(Object otro) {
        // Implementar
        return true;
    }

}
